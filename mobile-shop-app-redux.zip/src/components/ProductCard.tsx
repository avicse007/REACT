import { faShoppingCart, faHeart } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";

import Product from '../model/Product';

import {Link} from 'react-router-dom';

type Props = {
    product:Product
}
const ProductCard =  ({product}: Props) => {
     return   <div className="item col-md-4 mr-2">
    <div className="mb-r">
        <div className="card card-cascade wider">
                <div className="view overlay hm-white-slight">
                    <Link to={`/details/${product.productId}`}>
                    <img src={product.productImageUrl} className="img-fluid" alt="" width="360px" height="640px" />
                    </Link>
                </div>
                <div className="card-body text-center no-padding">
                <p className="card-title">
                    <strong>
                        <a>{product.productSeller}</a>
                    </strong>
                </p>
                <p className="card-text">{product.productDescription}</p>
                <div className="card-footer">
                    <span className="left">₹ {product.productPrice}</span>
                    <span className="right px-2">
                       <FontAwesomeIcon icon={faHeart} color="red" className='px-3'/>
                        <FontAwesomeIcon icon={faShoppingCart}  color="blue"/>
                    </span>
                </div>
            </div>

        </div>
    </div>
</div>
}

export default ProductCard;