import { useEffect, useState } from 'react'
import Product from '../model/Product';
import {useParams} from 'react-router-dom';
type Props = {}

export default function Details({}: Props) {
    let [product,setProduct] =  useState<Product>();
	let {id} = useParams();
	
	useEffect(() => {
		
	},[id]);

	if(product != null) {
		return(
			<div className="container">
                <h1>Seller : { product.productSeller}</h1>
				<h1>Name : { product.productDescription}</h1>
				<h2>Price: { product.productPrice} </h2>
                <img src={product.productImageUrl} />
			</div>
		)
	} else 
	return <h1>Product doesn't exist</h1>
}