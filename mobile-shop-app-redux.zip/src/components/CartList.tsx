import { Button } from "react-bootstrap";


type Props = {
	
}

const CartList = () => {
	return <div className="row">
		<div className="col-md-2">
			<img src="" style={{"width": "50px", height:"50px"} } />
			product.name
		</div>
		<div className="col-md-6 text-center">
			<Button  variant="outline-primary" >+</Button>
                Qty: product.qty
			<Button  variant="outline-primary">-</Button>
		</div>
		<div className="col-md-2">
			Price: ₹ product.price
		</div>
		<div className="col-md-2">
			Amount: ₹ product.amount
		</div>
		
	</div>
}

export default CartList;