
const Cart = () => {
	return <div className="container">
		cart!!!
	</div>
}

export default Cart;